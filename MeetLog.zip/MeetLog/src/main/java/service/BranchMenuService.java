package service;

import org.apache.ibatis.session.SqlSession;
import util.MyBatisSqlSessionFactory;
import dto.*;

import java.util.*;

public class BranchMenuService {

	public List<BranchMenu> listMenus(long companyId, int limit, int offset) {
		try (SqlSession s = MyBatisSqlSessionFactory.getSqlSession()) {
			Map<String, Object> p = new HashMap<>();
			p.put("companyId", companyId);
			p.put("limit", limit);
			p.put("offset", offset);
			return s.selectList("mapper.BranchMenuMapper.listMenus", p);
		}
	}

	public long createMenu(BranchMenu m, List<MenuIngredient> ings) {
		try (SqlSession s = MyBatisSqlSessionFactory.getSqlSession()) {
			s.insert("mapper.BranchMenuMapper.insertMenu", m); // useGeneratedKeys=true → id 채워짐
			if (ings != null && !ings.isEmpty()) {
				for (MenuIngredient mi : ings) {
					mi.setCompanyId(m.getCompanyId());
					mi.setMenuId(m.getId());
					s.insert("mapper.BranchMenuMapper.insertMenuIngredient", mi);
				}
			}
			
			return m.getId();
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public void updateMenu(BranchMenu m, List<MenuIngredient> ings) {
		try (SqlSession s = MyBatisSqlSessionFactory.getSqlSession()) {

			// 이미지 보존: 새 경로가 null이면 기존 값 유지
			if (m.getImgPath() == null) {
				Map<String, Object> p = new HashMap<>();
				p.put("companyId", m.getCompanyId());
				p.put("id", m.getId());
				BranchMenu prev = s.selectOne("mapper.BranchMenuMapper.selectMenu", p);
				if (prev != null)
					m.setImgPath(prev.getImgPath());
			}

			s.update("mapper.BranchMenuMapper.updateMenu", m);

			// 재료 라인 교체
			Map<String, Object> p = new HashMap<>();
			p.put("companyId", m.getCompanyId());
			p.put("menuId", m.getId());
			s.delete("mapper.BranchMenuMapper.deleteMenuIngredients", p);
			if (ings != null && !ings.isEmpty()) {
				for (MenuIngredient mi : ings) {
					mi.setCompanyId(m.getCompanyId());
					mi.setMenuId(m.getId());
					s.insert("mapper.BranchMenuMapper.insertMenuIngredient", mi);
				}
			}

			
		}
	}

	public void softDeleteMenu(long companyId, long menuId) {
		try (SqlSession s = MyBatisSqlSessionFactory.getSqlSession()) {
			Map<String, Object> p = new HashMap<>();
			p.put("companyId", companyId);
			p.put("id", menuId);
			s.update("mapper.BranchMenuMapper.softDeleteMenu", p);
			
		}
	}

	public List<MenuIngredient> listIngredients(long companyId, long menuId) {
		try (SqlSession s = MyBatisSqlSessionFactory.getSqlSession()) {
			Map<String, Object> p = new HashMap<>();
			p.put("companyId", companyId);
			p.put("menuId", menuId);
			return s.selectList("mapper.BranchMenuMapper.listIngredientsOfMenu", p);
		}
	}

	public void replaceMenuIngredients(long companyId, long menuId, List<MenuIngredient> items) {
		// 트랜잭션 커밋(프레임워크 설정에 따라 자동/수동)
		try (SqlSession s = MyBatisSqlSessionFactory.getSqlSession()) {
			Map<String, Object> p = new HashMap<>();
			p.put("companyId", companyId);
			p.put("menuId", menuId);
			s.delete("mapper.BranchMenuMapper.deleteMenuIngredients", p);
			for (MenuIngredient mi : items) {
				// companyId/menuId/materialId/qty 가 채워진 DTO
				s.insert("mapper.BranchMenuMapper.insertMenuIngredient", mi);
			}
			
		}

	}

	
}
